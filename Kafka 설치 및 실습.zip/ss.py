import matplotlib

print(matplotlib.__version__)
print(matplotlib.get_backend())